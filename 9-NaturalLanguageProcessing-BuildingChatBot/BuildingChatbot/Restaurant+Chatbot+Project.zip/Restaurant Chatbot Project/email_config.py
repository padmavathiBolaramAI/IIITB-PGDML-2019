
def Config():
	gmail_user = '****@gmail.com' # Gmail Username
	gmail_pwd = '****' #Gmail Password
	gmail_config = (gmail_user, gmail_pwd)
	return gmail_config